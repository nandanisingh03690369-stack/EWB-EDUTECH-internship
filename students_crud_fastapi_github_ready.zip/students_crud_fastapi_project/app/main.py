from contextlib import asynccontextmanager
from datetime import date
import sqlite3
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Response, status
from app.database import get_connection, init_db
from app.schemas import StudentCreate, StudentOut, StudentUpdate

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="Students Database CRUD API",
    description="A student-record management API built with FastAPI and SQLite.",
    version="1.0.0",
    lifespan=lifespan,
)

def row_to_student(row: sqlite3.Row) -> dict:
    return dict(row)

@app.get("/", tags=["Health"])
def root():
    return {"message": "Students CRUD API is running", "docs": "/docs"}

@app.post("/students", response_model=StudentOut, status_code=status.HTTP_201_CREATED, tags=["Students"])
def create_student(student: StudentCreate):
    data = student.model_dump(mode="json")
    try:
        with get_connection() as connection:
            cursor = connection.execute("""
                INSERT INTO students
                (name, date_of_birth, email, phone, course, address, enrollment_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                data["name"].strip(), data["date_of_birth"], data["email"],
                data.get("phone"), data.get("course"), data.get("address"),
                data.get("enrollment_date")
            ))
            connection.commit()
            row = connection.execute("SELECT * FROM students WHERE id = ?", (cursor.lastrowid,)).fetchone()
            return row_to_student(row)
    except sqlite3.IntegrityError as exc:
        if "students.email" in str(exc) or "UNIQUE constraint failed" in str(exc):
            raise HTTPException(status_code=409, detail="A student with this email already exists.")
        raise HTTPException(status_code=400, detail="Student record could not be created.")

@app.get("/students", response_model=list[StudentOut], tags=["Students"])
def list_students(
    name: Optional[str] = Query(default=None, description="Filter by part of a student's name"),
    course: Optional[str] = Query(default=None, description="Filter by course"),
    born_after: Optional[date] = Query(default=None, description="Only students born after this date"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    query = "SELECT * FROM students WHERE 1=1"
    params = []
    if name:
        query += " AND name LIKE ?"
        params.append(f"%{name.strip()}%")
    if course:
        query += " AND course LIKE ?"
        params.append(f"%{course.strip()}%")
    if born_after:
        query += " AND date_of_birth > ?"
        params.append(born_after.isoformat())
    query += " ORDER BY id LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    with get_connection() as connection:
        rows = connection.execute(query, params).fetchall()
        return [row_to_student(row) for row in rows]

@app.get("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def get_student(student_id: int):
    with get_connection() as connection:
        row = connection.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Student not found.")
    return row_to_student(row)

@app.put("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def replace_student(student_id: int, student: StudentCreate):
    data = student.model_dump(mode="json")
    try:
        with get_connection() as connection:
            existing = connection.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
            if existing is None:
                raise HTTPException(status_code=404, detail="Student not found.")
            connection.execute("""
                UPDATE students SET name=?, date_of_birth=?, email=?, phone=?, course=?, address=?, enrollment_date=?
                WHERE id=?
            """, (
                data["name"].strip(), data["date_of_birth"], data["email"],
                data.get("phone"), data.get("course"), data.get("address"),
                data.get("enrollment_date"), student_id
            ))
            connection.commit()
            row = connection.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
            return row_to_student(row)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="A student with this email already exists.")

@app.patch("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def update_student(student_id: int, student: StudentUpdate):
    changes = student.model_dump(exclude_unset=True, mode="json")
    if not changes:
        raise HTTPException(status_code=400, detail="Provide at least one field to update.")
    if "name" in changes and changes["name"] is not None:
        changes["name"] = changes["name"].strip()
        if not changes["name"]:
            raise HTTPException(status_code=422, detail="Name cannot be blank.")
    try:
        with get_connection() as connection:
            existing = connection.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
            if existing is None:
                raise HTTPException(status_code=404, detail="Student not found.")
            allowed = {"name", "date_of_birth", "email", "phone", "course", "address", "enrollment_date"}
            columns = [key for key in changes if key in allowed]
            if columns:
                sql = "UPDATE students SET " + ", ".join(f"{col} = ?" for col in columns) + " WHERE id = ?"
                connection.execute(sql, [changes[col] for col in columns] + [student_id])
                connection.commit()
            row = connection.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
            return row_to_student(row)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="A student with this email already exists.")

@app.delete("/students/{student_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Students"])
def delete_student(student_id: int):
    with get_connection() as connection:
        cursor = connection.execute("DELETE FROM students WHERE id = ?", (student_id,))
        connection.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Student not found.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
