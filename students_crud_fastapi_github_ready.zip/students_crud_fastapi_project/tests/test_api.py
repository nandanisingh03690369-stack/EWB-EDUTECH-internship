import os
import tempfile
from pathlib import Path

# Use a dedicated temporary SQLite file for tests.
_TEST_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_TEST_DB.close()
os.environ["DATABASE_PATH"] = _TEST_DB.name

from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db

init_db()
client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["docs"] == "/docs"

def test_create_list_update_delete_student():
    payload = {
        "name": "Test Student",
        "date_of_birth": "2005-04-12",
        "email": "test.student@example.com",
        "phone": "9000000000",
        "course": "B.Tech CSE"
    }
    created = client.post("/students", json=payload)
    assert created.status_code == 201, created.text
    student = created.json()
    student_id = student["id"]
    assert student["name"] == "Test Student"

    listed = client.get("/students")
    assert listed.status_code == 200
    assert any(item["id"] == student_id for item in listed.json())

    updated = client.patch(f"/students/{student_id}", json={"course": "AI"})
    assert updated.status_code == 200
    assert updated.json()["course"] == "AI"

    fetched = client.get(f"/students/{student_id}")
    assert fetched.status_code == 200
    assert fetched.json()["email"] == payload["email"]

    deleted = client.delete(f"/students/{student_id}")
    assert deleted.status_code == 204
    missing = client.get(f"/students/{student_id}")
    assert missing.status_code == 404

def test_duplicate_email_rejected():
    payload = {
        "name": "First Student",
        "date_of_birth": "2004-01-01",
        "email": "duplicate@example.com"
    }
    first = client.post("/students", json=payload)
    assert first.status_code == 201
    second_payload = {**payload, "name": "Second Student"}
    second = client.post("/students", json=second_payload)
    assert second.status_code == 409

def test_missing_student_returns_404():
    response = client.get("/students/999999")
    assert response.status_code == 404
