# Students Database CRUD Application

A GitHub-ready internship project implementing student record management with **Python, FastAPI, and SQLite**, based on the EWB assignment requirements.

## Features

- Create, read, update, and delete student records (CRUD)
- SQLite persistence
- Input validation with Pydantic
- Duplicate-email protection
- Helpful `404`, `409`, and validation error responses
- Search/filter by name, course, and date of birth
- Pagination with `limit` and `offset`
- Interactive API documentation
- Parameterized SQL queries to reduce SQL-injection risk

## Student fields

Required: `name`, `date_of_birth`, `email`

Optional: `phone`, `course`, `address`, `enrollment_date`

Dates must use ISO format: `YYYY-MM-DD`.

## Requirements

- Python 3.10 or newer
- pip

## Setup and run

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
```

If PowerShell blocks activation, you can run the commands using Command Prompt:

```bat
py -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open these addresses after starting the server:

- API: http://127.0.0.1:8000
- Swagger UI / interactive testing: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

The SQLite database (`students.db`) is created automatically on first startup. It is excluded from Git by `.gitignore`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/students` | Create a student |
| `GET` | `/students` | List students |
| `GET` | `/students/{student_id}` | Get one student |
| `PUT` | `/students/{student_id}` | Replace all editable student fields |
| `PATCH` | `/students/{student_id}` | Update selected fields |
| `DELETE` | `/students/{student_id}` | Delete a student |

### Example request: create a student

```json
{
  "name": "Aarav Sharma",
  "date_of_birth": "2005-04-12",
  "email": "aarav.demo@example.com",
  "phone": "9000000001",
  "course": "B.Tech CSE",
  "address": "Jaipur",
  "enrollment_date": "2024-08-01"
}
```

Use this JSON with `POST http://127.0.0.1:8000/students`.

### List and filter

- `GET /students`
- `GET /students?name=Aarav`
- `GET /students?course=CSE`
- `GET /students?born_after=2005-01-01`
- `GET /students?limit=20&offset=0`

### Example partial update

Send `PATCH /students/1` with:

```json
{
  "course": "Artificial Intelligence"
}
```

### Example delete

Send `DELETE /students/1`. A successful deletion returns HTTP `204 No Content`.

## Test the project

Install dependencies, then run:

```bash
pytest -q
```

## Upload to GitHub

1. Create a new, empty repository on GitHub.
2. Extract this project ZIP.
3. Open a terminal in the extracted `students_crud_fastapi_project` folder.
4. Run:

```bash
git init
git add .
git commit -m "Build students CRUD API with FastAPI and SQLite"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the example repository address with your own repository URL.

## Suggested demo flow

1. Open `/docs`.
2. Create a student using `POST /students`.
3. List records using `GET /students`.
4. Open the record using `GET /students/{student_id}`.
5. Update one field using `PATCH /students/{student_id}`.
6. Delete the record using `DELETE /students/{student_id}`.
7. Try a missing ID to demonstrate `404` handling and repeat a student email to demonstrate duplicate protection.

## Security and scope notes

- Use fictional/demo student data only.
- Do not commit real student personal information, credentials, or secrets.
- The optional Ollama AI extension is not included; the assignment states that it is optional and that the core CRUD application is sufficient.
- This is an educational starter project. Add authentication, authorization, deployment hardening, and privacy controls before using it with real student data.
